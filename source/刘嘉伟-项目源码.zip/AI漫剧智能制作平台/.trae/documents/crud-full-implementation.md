# CRUD 全量补齐实施计划

## Context

平台现有模块（项目/角色/分镜/镜头/时间线/任务）中，只有 Project 的增删改查齐全。角色缺手动创建与删除、分镜缺新增与删除、镜头版本缺编辑与删除、时间线缺删除、任务缺取消、用户缺资料修改；前端也几乎没有对应的删除/新增入口。本次按用户确认的范围**全部补齐**，并保证删除时各模块关联数据正确级联处理。

**删除策略（已确认）**：非项目实体采用级联硬删除（删分镜级联删 Shot+ShotVersion、seq 重排；删选中版本清 `selected_version_id`）；项目保持已有软删除。

## 已核实的代码事实

- ORM 级联已就绪：`Storyboard.shot`、`Shot.versions` 均带 `cascade="all, delete-orphan"`（models.py:199-222），`db.delete(sb)` 自动级联。
- `shots.selected_version_id` 是无 FK 的普通 Integer（models.py:209），删版本无约束冲突，仅需手动清空引用及可能的 `shot.video_url`。
- 角色/时间线无其他实体 FK 引用（分镜/时间线 items 不存 character_id），可安全硬删。
- `_run_task` 取任务时跳过 `canceled` 状态（task_engine.py:124）→ 排队中任务取消天然生效；运行中需协作式取消。
- 各 routes 文件已有归属校验 helper 可复用：`_get_owned_character`、`_get_owned_storyboard`、`_get_owned_shot`、`_get_owned_task`、`_get_owned_timeline`、`get_owned_project`。
- `TaskStatus.canceled` 枚举存在（models.py:86），前端 utils 已有"已取消"文案。

## 后端改动

### 1. `backend/app/schemas.py` — 新增 schema

- `CharacterCreate`（name 必填，description/prompt_template/voice 默认"longxiaochun"/voice_emotion/voice_speed）
- `StoryboardCreate`（shot_size/scene/dialogue/emotion/duration_sec 默认5/image_prompt；**不含 seq**，创建固定追加末尾）
- `ShotVersionUpdate`（prompt、seed 可选）
- `ProfileUpdate`（nickname）、`PasswordChange`（old_password、new_password min 6）

### 2. `backend/app/services/task_engine.py` — 取消机制

- 加 `class TaskCanceled(Exception)`、`cancel_task(db, task)`（置 canceled + `_publish`）、`check_canceled(db, task_id)`（独立查询最新状态，canceled 则抛 TaskCanceled）。
- `_run_task`（:133-147）handler 调用处包 `except TaskCanceled:`：先 `db.rollback()` 再置 `canceled`（不进重试，重试块只判 failed，无需改）。
- 长循环检查点：`_handle_image` 每版本生成前、`_handle_video` 轮询 while 每次循环（与 sleep(10) 同级）、`_handle_script` 在删旧分镜之前。短任务（tts/ref/composite）不加。

### 3. `backend/app/api/routes_tasks.py` — 取消端点

`POST /tasks/{task_id}/cancel`：`_get_owned_task` → 状态不在 (pending, queued, running) 则 400 → `task_engine.cancel_task` → 返回 `task_out`。

### 4. `backend/app/api/routes_characters.py` — 增/查/删

- `POST /projects/{project_id}/characters`：`get_owned_project` → 建 Character → `character_out`
- `GET /characters/{character_id}`：`_get_owned_character` → `character_out`
- `DELETE /characters/{character_id}`：硬删 → `{"ok": True, "message": "角色已删除"}`（无引用需清理）

### 5. `backend/app/api/routes_storyboards.py` — 增/查/删

- `POST /projects/{project_id}/storyboards`：`func.max(seq)` 取末尾 seq+1（空表 `or 0`），创建 Storyboard + 配套空 Shot（与 script handler 一致），需 `from sqlalchemy import func`
- `GET /storyboards/{storyboard_id}` → `storyboard_out`
- `DELETE /storyboards/{storyboard_id}`：`db.delete(sb)` ORM 级联删 shot+versions，随后剩余分镜 seq 归一化为 1..n，返回 `{"ok": True, ...}`

### 6. `backend/app/api/routes_shots.py` — 版本编辑/删除

- `PUT /shots/{shot_id}/versions/{version_id}`：body `ShotVersionUpdate`（exclude_unset 局部更新）→ `shot_version_out`
- `DELETE /shots/{shot_id}/versions/{version_id}`：若为选中版本 → `shot.selected_version_id = None`，且 `shot.video_url == version.video_url` 时一并置 None → 删除 → `{"ok": True, ...}`
- 新增 helper `_get_owned_version`（404 校验 shot_id 归属）

### 7. `backend/app/api/routes_timelines.py` — 删时间线

`DELETE /timelines/{timeline_id}`：`_get_owned_timeline` → 硬删 → `{"ok": True, ...}`

### 8. `backend/app/api/routes_auth.py` — 资料修改

- `PUT /auth/me`（ProfileUpdate）：更新 nickname → `user_out`
- `PUT /auth/me/password`（PasswordChange）：`verify_password` 校验原密码，错则 400；`hash_password` 更新
- 补充现有 import：`from ..schemas import ..., ProfileUpdate, PasswordChange`

## 前端改动

### 9. 项目删除入口

- `components/ProjectCard.vue`：封面角落加删除图标按钮（`@click.stop`），`ElMessageBox.confirm` → `api.delete(/projects/{id})` → `emit('deleted', id)`
- `views/Workspace.vue`、`views/Mine.vue`：`@deleted` 从本地列表移除
- `views/ProjectDetail.vue`：操作区加"删除项目"（plain danger），确认后删除并 `router.push('/')`

### 10. `views/Editor.vue` + `components/TaskProgress.vue`

- **剧本 Tab**：sec-head 加"新增分镜"（复用现有分镜弹窗，`sbForm.id=null` 走 POST，标题动态）；表格操作列加"删除"（confirm → DELETE → 本地移除，后端已重排 seq）
- **角色 Tab**："新增角色"（复用角色弹窗，POST vs PUT 分支）+ 角色卡加"删除"
- **画面 Tab**：版本条加"删除"（DELETE 版本后 `loadAll()` 全量刷新，处理选中版本被删情形）；加"编辑"弹窗（prompt/seed → PUT → loadAll）
- **成片 Tab**：sec-head 加"删除时间线"（无 currentTimeline 时 disabled）
- **任务取消**：TaskProgress 加"取消"链接（仅 pending/queued/running 显示，emit cancel）→ Editor 调 `POST /tasks/{id}/cancel` 并本地置 canceled（SSE 随后推送最终状态）

### 11. `views/Mine.vue` + `stores/auth.js`

- auth.js 加 `setUser(user)`（同步 localStorage 持久化）
- Mine.vue：资料卡加"编辑资料"弹窗（nickname → `PUT /auth/me` → `auth.setUser`）；账号设置加"修改密码"弹窗（原/新/确认密码，前端校验一致与长度）

## 不需改动

`api/index.js`（unwrap 直通 `{ok, message}`）、`stores/project.js`（删除后走 loadAll 全量刷新）、`router.py`（新端点挂既有 router）、`router/index.js`。

## 实施顺序

1. schemas.py → 2. task_engine 取消机制 → 3. routes_tasks/characters/storyboards/shots/timelines/auth → 4. 前端 TaskProgress → Editor → ProjectCard/Workspace/Mine/ProjectDetail → auth store/Mine → 5. 端到端验证

## 验证

1. 启动：`stop.ps1` → `start.ps1`（后端 8010、前端 5173），`http://localhost:8010/health` 返回 ok。
2. API 冒烟（登录取 token 后经 http://localhost:8010/docs 或 PowerShell Invoke-RestMethod）：
   - 建/删角色、建/删分镜（核对 seq 重排与 DB 级联删除 shots/versions）
   - 版本 PUT prompt/seed、DELETE 非选中与选中版本（核对 `shots.selected_version_id` 清空）
   - 取消排队中与运行中任务（运行中最迟在下个检查点停止）
   - 删除时间线、改昵称、错误原密码 400、正确改密后新密码登录成功
3. UI 端到端（http://localhost:5173）：工作台/我的页删项目、Editor 四个 Tab 的增删编辑、任务取消、改资料后顶栏显示名即时更新。
4. 回归：软删项目下属资源端点仍 404，项目列表不再出现。
