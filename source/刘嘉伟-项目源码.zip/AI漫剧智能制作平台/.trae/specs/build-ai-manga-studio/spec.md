# AI 漫剧智能制作平台（全栈 MVP）Spec

## Why
依据 `D:\drama\PRD.md`（v1.4）与 `D:\drama\Agnes AI 模型选择.md`，从零搭建一个可本地运行的 AI 漫剧创作平台：输入灵感 → 多智能体编排产出剧本/分镜/角色 → 多模态生成画面/视频/配音 → FFmpeg 合成成片，前端为 Vue3 + Element Plus 的「导演工作台」（Apple Dark 双主题）。

## What Changes
- **新增后端**（FastAPI + DeepAgents + MySQL8，`backend/`）：
  - 基础设施：`.env` 配置、SQLAlchemy 2.0（pymysql）连接 `localhost:3306/ai_manga_studio2`（root/123456），启动时自动建库建表（`metadata.create_all`）、CORS、静态文件服务（本地存储代替 MinIO/S3）
  - 认证：注册/登录（JWT Bearer）、users/roles/user_roles、默认 creator 角色
  - Provider 抽象层：Agnes（文本 `agnes-2.5-flash` OpenAI 兼容 `/v1/chat/completions`、图像 `agnes-image-2.1-flash` `/v1/images/generations`、视频 `agnes-video-2.5-flash` 异步 `/v1/videos` + 轮询）、DashScope TTS（可配置 key，未配置时任务明确报错）
  - DeepAgents 智能体编排：编剧智能体（灵感→结构化剧本+分镜脚本+角色草稿，JSON 落库）、总导演流水线（阶段顺序执行：剧本→角色→画面→视频→配音→合成）
  - 数据模型（12 张核心表）：users/roles/user_roles/projects/characters/storyboards/shots/shot_versions/assets/gen_tasks/agent_runs/timelines
  - 异步任务引擎：`gen_tasks` 状态机（pending→queued→running→succeeded/failed/canceled），进程内 asyncio worker 池（本地化替代 Celery+Redis），幂等键、重试上限、SSE 进度事件（进程内事件总线）
  - 核心接口（`/api/v1`）：auth、projects CRUD、generate-script、characters、generate-ref、storyboards、generate-image、shots、抽卡 versions、select-version、generate-video、generate-voice、试听、tasks、SSE `/projects/{id}/stream`、timelines、composite、export
  - FFmpeg 合成：时间线（shots+音频+字幕）→ 拼接输出 mp4，产物存本地并写 assets
- **新增前端**（Vue3 + Vite + Element Plus + Pinia + Vue Router，`frontend/`）：
  - 设计系统 `tokens.css`：Apple Dark 默认深色 + Apple Light 可切换（`data-theme` + localStorage）
  - 页面：登录/注册、工作台（项目概览/统计/搜索/项目卡）、创作（灵感输入→风格/比例→一键生成）、我的（作品列表/账号设置）、项目详情、创作工作台（左侧 6 步流水线 Tab：剧本/角色/分镜/画面/配音/成片，含分镜表格编辑、角色形象卡、抽卡对比、版本选定、视频预览、TTS 试听、时间线/成片播放）
  - 实时进度：EventSource 订阅 SSE，任务进度条与失败重试
- **新增运维脚本**：`start.ps1` / 一键启动（自动创建 venv、安装依赖、起后端+前端 dev server）与一键停止（按端口/PID 清理）

### 简化决策（本地 MVP，与 PRD 差异）
- 任务队列用进程内 asyncio worker（PRD 中的 Celery+Redis 不引入）；对象存储用本地磁盘目录（FastAPI StaticFiles 托管）；SSE 用进程内事件总线。接口与数据模型保留 PRD 抽象，后续可平替。
- 范围聚焦 MVP+V1 核心（P0 全量 + P1 关键项：视频链、TTS、QC 阈值自动重抽、FFmpeg 合成）；RBAC 简化为 creator/admin 两角色，额度计费、监控告警、内容合规不在本期。

## Impact
- Affected specs: 无（首次创建）
- Affected code: 全新 `backend/`、`frontend/`、`start.ps1`、`.env`；不改动 `PRD.md` 与 `Agnes AI 模型选择.md`

## ADDED Requirements

### Requirement: 后端基础设施与数据库
系统 SHALL 提供 FastAPI 应用，连接 MySQL8（localhost:3306/ai_manga_studio2，root/123456），启动时自动创建数据库与全部核心表，并提供 `/health` 健康检查。

#### Scenario: 首次启动自动建库建表
- **WHEN** 后端启动且 `ai_manga_studio2` 库不存在
- **THEN** 自动 `CREATE DATABASE ai_manga_studio2` 并建全部 12 张核心表，`/health` 返回 ok

### Requirement: 注册登录与 JWT 认证
系统 SHALL 提供注册/登录接口，签发 JWT Bearer；除 auth 与 health 外接口均需认证。

#### Scenario: 登录成功
- **WHEN** 用户以正确账号密码 POST `/api/v1/auth/login`
- **THEN** 返回 `access_token`，后续请求带 Bearer 可访问

### Requirement: Agnes Provider 抽象层
系统 SHALL 封装 Agnes 三模型统一调用：文本（chat/completions）、图像（images/generations，含 size/ratio）、视频（异步建任务+轮询查询），API key 来自 `.env`（`sk-sI4PolZECU1beZPLIeVlOl9LeQO9uu4YBcIovR6N2AJxxK8h`）。

#### Scenario: 文生图调用成功
- **WHEN** 提交图像生成任务（prompt/size/ratio）
- **THEN** worker 调用 `agnes-image-2.1-flash`，产物图下载到本地存储并写回 shot_versions

### Requirement: DeepAgents 剧本生成
系统 SHALL 通过 DeepAgents 编排编剧智能体，调用 agnes-2.5-flash 将灵感转为结构化 JSON（分镜脚本：景别/画面描述/台词/情绪 + 角色草稿），解析后落库 storyboards/characters。

#### Scenario: 灵感生成剧本
- **WHEN** POST `/api/v1/projects/{id}/generate-script` 携带灵感文本
- **THEN** 创建 gen_task 并异步执行，完成后 storyboards 与 characters 落库，SSE 推送完成事件

### Requirement: 图像生成与抽卡
系统 SHALL 支持按分镜+角色提示词生成图像（每镜头多版本抽卡，默认 2-4 版本），版本写入 shot_versions，支持人工 `select-version` 选定与重新生成（换 seed/提示词）。

#### Scenario: 抽卡与选定
- **WHEN** 对某 storyboard 提交 generate-image（count=2）
- **THEN** 产生 2 个候选版本，POST select-version 后该版本标记为 selected

### Requirement: 视频生成链
系统 SHALL 支持对选定关键帧图生视频（agnes-video-2.5-flash，异步任务+轮询，4-12 秒、比例 9:16/16:9），完成后视频写入 shot 版本并可前端预览。

#### Scenario: 图生视频
- **WHEN** POST `/api/v1/shots/{id}/generate-video`
- **THEN** 异步建 Agnes 视频任务并轮询至 completed，视频 URL 落库、任务状态 succeeded

### Requirement: 配音 TTS
系统 SHALL 支持按角色音色将台词合成语音（DashScope TTS，key 可配置），支持单句试听；未配置 key 时任务失败并返回明确错误信息。

#### Scenario: 台词配音
- **WHEN** POST `/api/v1/storyboards/{id}/generate-voice`
- **THEN** 生成台词音频文件存本地，写入 assets 并关联分镜

### Requirement: FFmpeg 成片合成与导出
系统 SHALL 支持创建时间线（选定镜头顺序+字幕文案），触发 FFmpeg 合成（图/视频+音频+字幕，统一 9:16 分辨率），输出成片 mp4 并提供预览/下载。

#### Scenario: 合成成片
- **WHEN** POST `/api/v1/timelines/{id}/composite`
- **THEN** FFmpeg 按时间线渲染输出成片文件，assets 记录 output_url，前端可播放

### Requirement: 任务中心与 SSE 实时进度
系统 SHALL 提供 gen_tasks 状态机与任务列表接口（按类型/状态筛选、失败重试），并通过 `/api/v1/projects/{id}/stream`（SSE）实时推送任务进度/完成/失败事件。

#### Scenario: 前端实时收到进度
- **WHEN** 任一项目任务状态变化
- **THEN** 订阅该项目的 EventSource 收到状态事件，延迟 <2s

### Requirement: 前端创作工作台
前端 SHALL 实现 Apple Dark（默认）/Apple Light 双主题的 Vue3+Element Plus 应用，包含登录、工作台、创作、我的、项目详情、创作工作台（6 步流水线 Tab：剧本/角色/分镜/画面/配音/成片）页面，调用全部后端能力并消费 SSE 进度。

#### Scenario: 端到端创作流程
- **WHEN** 用户登录后在「创作」输入灵感一键生成
- **THEN** 依次完成剧本→角色→分镜图（抽卡）→视频→配音→成片，全程在创作工作台可视化操作

### Requirement: 一键启停脚本
系统 SHALL 提供 `.ps1` 脚本支持一键启动（创建 venv/安装依赖/起后端与前端 dev server）与一键停止（终止对应进程），并进行启动验证。后端端口实现时定为 8010（本机 8000 被其他常驻服务占用），前端 5173。

#### Scenario: 一键启动后可访问
- **WHEN** 执行启动脚本
- **THEN** `http://localhost:8010/health` 与 `http://localhost:5173` 均可访问；执行停止脚本后端口释放

## REMOVED Requirements
（无）
