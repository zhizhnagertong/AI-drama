# Checklist

> 注：因本机 8000 端口被其他常驻服务占用，后端实际运行端口为 8010（start.ps1/stop.ps1/vite proxy 已同步）。
> 2026-09-08 补充：更换有效 Agnes key 并修正 base URL 为 api.agnes-ai.cn 后，已用真实模型跑通全部生成链路（含修复 routes_characters 缺失导入、Agnes seed 范围 -1~999 两个问题）。

- [x] 后端启动自动创建 ai_manga_studio2 库与 12 张核心表（物理 13 张：roles+user_roles 为两条独立定义），`/health` 返回 ok
- [x] 注册/登录可用，JWT 保护除 auth/health 外所有接口
- [x] Agnes 文本模型真实生成结构化剧本落库（实测：8 条分镜 + 2 个角色，任务 succeeded）
- [x] Agnes 图像生成真实执行，抽卡 2 版本落库，select-version 与重新生成可用（实测：5.7MB 2K 分镜图 ×2、角色参考图 succeeded）
- [x] Agnes 视频异步任务建单+轮询完成，视频可预览（实测：图生视频 succeeded，2.4MB mp4）
- [x] TTS 配音生成音频（DASHSCOPE_API_KEY 未配置时返回 400 明确错误，实测通过），试听接口可用
- [x] FFmpeg 按时间线合成成片 mp4（1080x1920 h264+yuv420p+字幕烧录），/static 200 可预览，export 返回 output_url（实测：真实视频合成成片 2.5MB）
- [x] gen_tasks 状态机与 SSE 进度推送正常（SSE 200 实测），失败任务可重试
- [x] 前端双主题（深色默认/浅色切换）与 6 个页面完整可用（npm run build 通过，dev server 200）
- [x] 前端创作工作台 6 步流水线 Tab 可视化操作，SSE 进度条实时更新
- [x] start.ps1 一键启动前后端成功（8010/5173 均可访问），stop.ps1 停止并释放端口
- [x] 端到端流程（灵感→成片）真实模型验证通过：灵感→剧本→角色参考图→抽卡→选定→图生视频→合成→导出（项目 ID 25；DASHSCOPE_API_KEY 未配置，配音环节待用户配置后可用）
