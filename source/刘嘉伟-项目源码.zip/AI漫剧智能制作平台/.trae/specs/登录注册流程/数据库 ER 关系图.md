erDiagram
    users ||--o{ refresh_tokens : "拥有多个"
    users ||--o{ login_logs : "产生多条"
    users ||--|| user_profiles : "一对一"

    users {
        bigint id PK "主键自增"
        varchar username UK "用户名 3-20位"
        varchar email UK "邮箱"
        varchar password_hash "bcrypt加密"
        tinyint status "0禁用 1正常"
        datetime locked_until "锁定截止时间"
        tinyint fail_count "连续失败次数"
        datetime created_at "创建时间"
        datetime updated_at "更新时间"
    }

    user_profiles {
        bigint id PK
        bigint user_id FK "用户ID"
        varchar nickname "昵称"
        varchar avatar "头像URL"
        varchar bio "简介"
        datetime birthday "生日"
        datetime created_at
        datetime updated_at
    }

    refresh_tokens {
        bigint id PK
        bigint user_id FK "用户ID"
        varchar token UK "Token字符串"
        varchar device_id "设备指纹"
        varchar ip_address "登录IP"
        varchar user_agent "浏览器UA"
        datetime expires_at "过期时间"
        datetime created_at
    }

    login_logs {
        bigint id PK
        bigint user_id FK "用户ID"
        tinyint action "1登录 2登出 3失败"
        varchar ip_address "IP地址"
        varchar user_agent "UA"
        varchar location "地理位置"
        datetime created_at
    }