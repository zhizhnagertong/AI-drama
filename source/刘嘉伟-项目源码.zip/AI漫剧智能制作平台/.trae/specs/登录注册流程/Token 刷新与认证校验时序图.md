sequenceDiagram
    autonumber
    actor U as 用户/浏览器
    participant F as Vue3 前端
    participant R as Router Guard
    participant A as Axios 拦截器
    participant N as Nginx
    participant API as FastAPI
    participant M as MySQL
    participant S as Redis

    %% 登录阶段
    U->>F: 输入账号密码点击登录
    F->>A: POST /api/auth/login
    A->>N: 转发请求
    N->>API: /api/auth/login
    API->>M: SELECT password_hash FROM users
    M-->>API: 返回用户数据
    API->>API: bcrypt.verify 校验密码
    API->>API: 生成 access_token(15min)<br/>生成 refresh_token(7day)
    API->>M: INSERT refresh_tokens
    API-->>N: 200 + {access_token, refresh_token}
    N-->>A: 返回响应
    A->>F: 存储 token 到 Pinia + localStorage
    F->>U: 跳转 /dashboard

    %% 正常请求
    U->>F: 访问受保护页面
    F->>R: 路由守卫拦截
    R->>F: 检查 Pinia 中 token 存在
    F->>A: 发起 API 请求
    A->>A: 请求头注入<br/>Authorization: Bearer <token>
    A->>N: 带 Token 请求
    N->>API: 转发请求
    API->>API: JWT 解码 + 过期校验
    API->>M: 执行业务 SQL
    M-->>API: 返回数据
    API-->>N: 200 + 业务数据
    N-->>A: 返回响应
    A->>F: 渲染页面
    F->>U: 展示内容

    %% Token 过期刷新
    U->>F: 页面停留超过15分钟
    F->>A: 发起新请求
    A->>API: 携带过期 access_token
    API-->>A: 401 Token Expired
    A->>A: 拦截 401 错误
    A->>API: POST /api/auth/refresh<br/>携带 refresh_token
    API->>M: 校验 refresh_token 有效性
    API->>S: 检查 Token 黑名单
    API->>API: 生成新 access_token
    API-->>A: 200 + 新 access_token
    A->>F: 更新 Pinia 中 token
    A->>API: 重试原请求
    API-->>A: 返回业务数据
    A->>F: 无感刷新完成