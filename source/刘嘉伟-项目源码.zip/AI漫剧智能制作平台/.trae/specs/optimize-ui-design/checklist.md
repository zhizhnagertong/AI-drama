# Checklist

> 规范基准：`ai_manhua_ui_design_spec.md`（源自参考稿 `app.html`）。逐节对照验收。
> 验证方式：代码级静态检查 + `npm run build` + dev server 可访问性（5173/8010 均 200）。

## 设计系统（规范 §3-§7、§14）
- [x] tokens.css 色彩与规范 §3.1 完全一致（#000/#1C1C1E/#2C2C2E、#0071E3 族、文字 100/60/40%、border .08/.12）
- [x] 字体栈 Inter + Noto Sans SC + SF Mono（§4.1），index.html 已加载（Google Fonts display=swap + preconnect）
- [x] 圆角 8/12/18/24/980 五级（§6）；阴影 sm/md/lg/xl 四级纯黑（§7）
- [x] 缓动 cubic-bezier(.16,1,.3,1) 与 (.4,0,.2,1)（§14.1）；时长符合 §14.2 表
- [x] v-reveal 指令：800ms 淡入上移 + 1-6 级联延迟 + reduced-motion 直接可见（§14.4）
- [x] 主按钮胶囊 + 顶部高光 + hover 蓝光晕 + active scale(.97)（§8.2/8.3）；次按钮半透明 + hairline；Ghost hover 浅底
- [x] 输入 44px/12px 圆角/surface 底/focus 3.5px 蓝环/placeholder 40% 白（§9）
- [x] tag 胶囊 4px12px/12px/600 + 6px 状态圆点（§11）；弹窗 480px/24px/60% 遮罩 blur8（§17.1）；Toast 底部白底黑字胶囊（§17.2）

## 页面结构（规范 §12、§13）
- [x] 顶栏：60px 毛玻璃 + 滚动阴影 + 30px 蓝渐变品牌块 + 36px 胶囊导航（active 10% 白）+ <768px 汉堡滑入菜单含主题入口（§12）
- [x] 工作台：Hero（24px + 蓝渐变 + mono 统计 + 右侧 CTA）→ 搜索/chip 工具栏 → 1/2/3 列网格 → 虚线空状态（§13.1）
- [x] 项目卡：16:9 封面 + 左上状态 tag + 右上 hover 更多 + 18/20px 信息区 + hover 上浮 3-6px（§10.3）
- [x] 创作页：1fr/1.1fr 分栏 + create-panel 24px/32px + style-grid 2 列选项 + aspect-row 等宽 + 全宽生成 CTA（§13.2）
- [x] 详情页：back-btn + 28px/800 标题 + meta tag + 2px 蓝下划线 Tab + mono count 徽标 + ep-card（mono 集数 pill + divider footer + 箭头）+ asset-grid 2/3/4 列 1:1 缩略图（§13.3）
- [x] 编辑器：fixed 全屏 + 56px 顶栏 + 260px 侧栏（active 蓝底/绿勾/28px icon 方块/脉冲圆点）+ 900px 居中内容 + <1024px 抽屉 + 48px 浮动开关（§13.4）
- [x] 我的：横向信息卡（80px 蓝渐变头像 + 28px 标题 + mono 统计）+ setting-card（40px 图标块 radius10 + hover 增强）（§13.5）
- [x] Login：纯净背景 + 24px 卡片 + shadow-xl + fadeUp 级联入场

## 响应式（规范 §15）
- [x] 断点 640/768/1024 网格列数与导航行为正确（代码级验证）
- [x] 移动端：搜索满行、单列网格、创作页单列、编辑器抽屉、页边距 16-24px
- [x] 容器 max-width 1200px + padding 24/40/48 响应式

## 无障碍与约束（规范 §18）
- [x] 图标按钮 aria-label（8 个文件覆盖）、交互控件 ≥32px、键盘可达 + focus 可见
- [x] 状态不只靠颜色（圆点 + 文字）
- [x] img 全部有 alt 与宽高；reduced-motion 降级
- [x] 无 `transition: all`、无裸 `outline: none`、无 `div @click` 伪按钮（grep 0 残留）
- [x] 文案「…」省略号字符（无字面 "..." 模板文案）

## 验证
- [x] npm run build 通过；无未定义 CSS 变量（72 个引用 0 缺失）
- [x] 双主题令牌完整（浅色为规范深色值的等价适配，[data-theme='light'] 覆盖齐全）
- [x] 375/768/1440px 断点代码级验证通过；dev server（5173）运行中，最终视觉以用户预览为准
- [x] CRUD/API/路由/stores 零改动（api/router/project/theme/utils 未被修改）
