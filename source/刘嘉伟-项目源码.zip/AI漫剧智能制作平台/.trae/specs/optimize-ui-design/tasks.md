# Tasks

> 规范基准：[ai_manhua_ui_design_spec.md](file:///d:/drama/.trae/specs/optimize-ui-design/ai_manhua_ui_design_spec.md)（提取自参考稿 `app.html`）。
> 约束：纯视觉/动效/结构优化，**不改任何 CRUD、API、路由与数据流**。

- [x] Task 1: 设计令牌与全局样式对齐规范
  - [x] 1.1 `tokens.css` 对齐规范第 3/4/6/7/14 节：色彩（#000/#1C1C1E/#2C2C2E、primary #0071E3 族、文字 100/60/40%、border .08/.12）、字体（Inter + Noto Sans SC + SF Mono）、圆角（8/12/18/24/980）、四级阴影、缓动（.16,1,.3,1 与 .4,0,.2,1）、时长、--grad-1..8 高饱和封面族、--thumb-bg；旧变量名保留别名
  - [x] 1.2 `main.css` 对齐规范第 8/9/10/11/17 节：.g-card（18px + shadow-sm + hover 抬升）、.g-page（1200px 容器 + 响应式 padding 24/40/48 + 顶部 100px）、.g-empty（2px 虚线 + 280px）、.glass-bar（60% 黑 + blur20 saturate180% + scrolled 阴影）、reveal 类与 fadeUp/pulse 关键帧、reduced-motion 降级；EP 定制：胶囊主按钮（顶部高光 + hover 蓝光晕 + active scale.97）、输入 focus 3.5px 光环、tag 胶囊 soft 底、tabs 2px 蓝下划线、dialog 24px + 60% 遮罩 blur8、Toast 白底黑字胶囊
  - [x] 1.3 `index.html` 引入 Inter + Noto Sans SC（display=swap + preconnect）、theme-color #000、蓝渐变 favicon
  - [x] 1.4 新增 `utils/directives.js` v-reveal 指令并在 main.js 注册（IntersectionObserver + reveal-delay-1..6）
  - [x] 1.5 验证：`npm run build` 通过；grep 全站 var(--*) 无缺失

- [x] Task 2: MainLayout 顶栏对齐规范第 12 节
  - [x] 2.1 60px 毛玻璃顶栏 + 滚动 shadow；30px 蓝渐变品牌块（radius 9px）+ 16px/700 文字；36px 胶囊导航（active 10% 白底 + 白字 + 轻阴影）、15px 线性 svg 图标
  - [x] 2.2 右侧「新建」蓝胶囊 + 头像 34px 蓝渐变（hover scale1.05）+ 主题开关（aria-label 保留）
  - [x] 2.3 <768px 汉堡三线 + 全屏滑入移动菜单（translateY 0.4s ease-out，含导航 + 主题入口）
  - [x] 2.4 验证：build 通过

- [x] Task 3: 复用组件对齐规范第 10.3/11 节
  - [x] 3.1 ProjectCard：16:9 封面 + --thumb-bg/渐变占位 + 影片图标；状态 tag 左上（黑 60% blur + 6px dot）；更多/删除右上 hover 显现；body 18/20px + 16px/700 truncate + 12.5px meta（tag-primary + N角色·N集 + mono 时间）；hover translateY(-4px)+shadow-lg；v-reveal
  - [x] 3.2 TaskProgress：surface 容器 + radius-lg + shadow-lg；行 divider 分隔；状态 pill soft 底；重试/取消 ghost 小按钮；enter/leave opacity+translateY(8px) .3s；aria-live 保留
  - [x] 3.3 验证：build 通过

- [x] Task 4: Login 页对齐规范视觉语言
  - [x] 4.1 纯净背景 + 低透明蓝渐变光晕（无 blur 光斑）；卡片 surface/24px 圆角/shadow-xl/32px padding；品牌块 44px 蓝渐变；标题 26px/800/-1px
  - [x] 4.2 fadeUp .5s 级联入场（品牌/卡片/页脚 0/.1/.2s）；表单 label/autocomplete/placeholder「…」保留；≤768px 全宽
  - [x] 4.3 验证：build 通过

- [x] Task 5: Workspace + Create + Mine 对齐规范第 13.1/13.2/13.5 节
  - [x] 5.1 Workspace：Hero（24px + 135° 蓝渐变 + 40/48px padding + 32px/800 标题 + mono 统计 + 右侧新建 CTA）；toolbar（pill 搜索 + filter-chip 组 + 排序 select）；project-grid 1/2/3 列 gap 20px + v-reveal 级联；虚线空状态
  - [x] 5.2 Create：1fr/1.1fr 分栏（<1024 单列）；create-panel（surface/24px/32px）；textarea 规范态；style-grid 2 列选项卡 + aspect-row 等宽选项（选中蓝框淡蓝底）；全宽 btn-lg 生成 CTA；右侧 recent-works
  - [x] 5.3 Mine：横向信息卡（80px 蓝渐变头像 + 28px/800 标题 + mono 统计）；setting-card 行列表（40px 图标块 radius10 + 标题/描述 + 右侧控件/箭头 + hover 增强）；保留 switch/模型/清缓存逻辑
  - [x] 5.4 验证：build 通过

- [x] Task 6: ProjectDetail 对齐规范第 13.3 节
  - [x] 6.1 header：40px back-btn + 封面（radius-lg + thumb-bg）+ 28px/800 标题 + 13.5px meta（tag）+ 右侧操作按钮
  - [x] 6.2 tabs：2px 蓝下划线 + mono count 徽标（active 蓝底）
  - [x] 6.3 剧集卡：ep-grid 1/2 列 gap 16px；ep-num mono pill（10px label + 18px/800 序号）+ badges + 16px/700 标题 + meta-row（success 项）+ footer divider + hover 箭头位移
  - [x] 6.4 素材库：asset-grid 2/3/4 列；1:1 thumb + 左下 kind 黑 blur 徽标 + 13px/600 truncate 名称；视频/音频容器化
  - [x] 6.5 v-reveal 级联；≤768px 纵向；验证 build 通过

- [x] Task 7: Editor 对齐规范第 13.4 节
  - [x] 7.1 骨架：fixed 全屏 + fadeUp 入场；56px 顶栏（黑 80% blur + 36px 返回 + truncate 标题 + pill 元信息 + 操作区）；260px 侧栏（surface + 右 divider）；editor-main 900px 居中 + 28/32/48 padding
  - [x] 7.2 步骤条：sidebar-item（28px icon 方块 + 13.5px/600 名称 + 11px 描述；active 12% 蓝底 #5AC8FA 字 + icon 蓝底白字；done 绿底 ✓；当前 label 脉冲圆点 pulse 2s）
  - [x] 7.3 六 section：step-header（mono step-num 01-06 + 18px/700 名称）；char-grid 1/2/3 列 + char-card（aspect 1 视觉 + 48px/800 首字）；shot-grid + shot-card（16:9 visual + sel ✓ 徽标 + qc tag + 36px 版本条 .on 蓝框光环）；dub-row（44px 头像 + meta + 操作）；timeline-panel（tl-label + 48px track + clip）；表格/视频容器化
  - [x] 7.4 <1024px 侧栏抽屉 + 48px 浮动开关；section 切换 fadeUp .3s；验证 build 通过

- [x] Task 8: 整体验证与走查（依赖 Task 2-7）
  - [x] 8.1 `npm run build` 通过；全站 var(--*) 无缺失
  - [x] 8.2 修复走查残留：7 处 `transition: all`（MainLayout:370、Create:280/315/356、Mine:385、ProjectDetail:496、Workspace:280）与 Create.vue:279 `outline: none` → 列出具体属性 / 依赖全局 focus-visible（复查为 0 残留）
  - [x] 8.3 按规范逐节复查：色彩/圆角/阴影/字号/间距与规范表一致；无偏离值残留（tokens/main 均取自规范值；img 全部有 alt；aria-label 覆盖 8 文件；无 div/span @click 伪按钮；无字面 "..." 文案）
  - [x] 8.4 dev server 运行确认（5173/8010 均 200）；build 产物含新令牌与 Inter 字体；浏览器逐档目检由用户在预览中确认
  - [x] 8.5 确认 CRUD/API/路由/stores 零改动（api/router/project/theme/utils 文件时间戳未变；auth.js 为标准 JWT 逻辑无 UI 改动混入）

# Task Dependencies
- Task 1 为全部基础；Task 2/3/4 依赖 Task 1 可并行；Task 5/6 依赖 1+3；Task 7 依赖 1+2+3；Task 8 收尾
