# 优化 UI 布局与设计 Spec

> **规范来源**：[ai_manhua_ui_design_spec.md](file:///d:/drama/.trae/specs/optimize-ui-design/ai_manhua_ui_design_spec.md)（提取自参考稿 `app.html`）。本增量以该规范为唯一视觉基准，所有实现必须与之一致。

## Why
现有前端与设计规范（纯黑背景 + 深灰卡片 + 蓝色主操作 + 大圆角 + 毛玻璃导航 + 轻量阴影 + 微动效 + 响应式网格）存在系统性偏差：令牌值不一致（文字透明度、圆角、阴影、缓动曲线）、缺少滚动入场动效、部分页面结构（工作台 Hero、创作页分栏、详情页卡片网格、编辑器侧栏）与规范定义的页面级结构不符。

## 设计基准（摘自规范）
- **色彩**：`--bg #000`、`--surface #1C1C1E`、`--surface-raised #2C2C2E`、`--surface-hover rgba(255,255,255,.06)`、`--primary #0071E3`（hover #0077ED / press #0062C4）、`--success #34C759`、`--danger #FF3B30`、`--warning #FF9F0A`、文字三级 100%/60%/40% 白、`--border rgba(255,255,255,.08)`、`--border-strong .12`
- **字体**：Inter + Noto Sans SC 栈；数字/时间用 SF Mono 等宽
- **圆角**：8 / 12 / 18 / 24 / pill(980px)
- **阴影**：sm `0 1px 3px/.3`、md `0 4px 16px/.4`、lg `0 8px 32px/.5`、xl `0 16px 48px/.6`
- **动效**：`--ease-out cubic-bezier(.16,1,.3,1)`、`--ease-smooth cubic-bezier(.4,0,.2,1)`；按钮 hover 180-200ms、卡片 hover 300-400ms、页面进入 300ms fadeUp、滚动显现 800ms reveal、弹窗 200-250ms；`prefers-reduced-motion` 降级
- **响应式断点**：640 / 768 / 1024 / 1200

## What Changes
- **设计令牌全面对齐规范色值/字体/圆角/阴影/动效**（`tokens.css`），浅色主题作为等价适配保留
- **全局样式与 Element Plus 定制对齐规范组件形态**（`main.css`）：胶囊按钮（顶部高光、hover 蓝光晕、active scale .97）、输入 44px/12px 圆角/focus 3.5px 蓝光环、tag 胶囊半透明 + 6px 状态圆点、弹窗 24px 圆角 + 60% 黑遮罩 + 8px blur、Toast 白底黑字胶囊
- **新增 v-reveal 滚动入场指令**（IntersectionObserver + 800ms ease-out + 1-6 级联延迟），全站页面区块应用
- **页面结构对齐规范第 13 节**：工作台 Hero 区（24px 圆角蓝渐变 + mono 统计 + 右侧主 CTA）+ 搜索/筛选 chip 工具栏 + 1/2/3 列项目网格 + 虚线空状态；创作页 1fr/1.1fr 左右分栏 + style-grid/aspect-row 选项卡；详情页返回按钮 + 2px 蓝下划线 Tab + 数量徽标 + ep-card/asset-card 网格；编辑器 fixed 全屏 + 56px 顶栏 + 260px 侧栏（当前步蓝底/完成绿勾/图标方块）+ 900px 居中内容 + <1024px 抽屉与浮动开关；我的页横向信息卡（80px 蓝渐变头像）+ setting-card 行列表
- **顶栏对齐规范第 12 节**：60px 毛玻璃、滚动加阴影、30px 蓝渐变品牌块、36px 胶囊导航（active 10% 白底）、<768px 汉堡 + 全屏滑入移动菜单
- **保留既有无障碍成果**（aria-label、键盘可达、focus-visible、reduced-motion、img alt/宽高）
- 纯前端视觉/动效改动，**不改动任何后端接口、路由结构、数据流与 CRUD 功能**（**非破坏性**）

## Impact
- Affected specs：build-ai-manga-studio（仅视觉层，接口契约不变）
- Affected code：
  - 设计系统：`frontend/src/styles/tokens.css`、`frontend/src/styles/main.css`、`frontend/index.html`（Inter 字体）
  - 指令：`frontend/src/utils/directives.js`（v-reveal，注册于 main.js）
  - 布局/页面/组件：`MainLayout.vue`、`{Login,Workspace,Create,Mine,ProjectDetail,Editor}.vue`、`{ProjectCard,TaskProgress}.vue`

## ADDED Requirements

### Requirement: 规范令牌系统
系统 SHALL 在 `tokens.css` 中提供与规范第 3/4/6/7/14 节完全一致的令牌（色值、字体栈、圆角 8/12/18/24/pill、四级阴影、两条缓动曲线、动效时长、断点）。

#### Scenario: 卡片使用规范基础样式
- **WHEN** 渲染任意 `.g-card`
- **THEN** 为 #1C1C1E 底、1px 8% 白描边、18px 圆角、shadow-sm，hover 边框增强 + 阴影加深 + 上浮 3~6px（transition 300-400ms ease-out）

### Requirement: 滚动入场动效
系统 SHALL 提供 `v-reveal` 指令：元素进入视口时执行 800ms ease-out 淡入上移（translateY(30px)→0），支持 1-6 级联延迟，`prefers-reduced-motion` 下直接可见。

#### Scenario: 项目网格级联入场
- **WHEN** 工作台项目卡片进入视口
- **THEN** 按索引应用 reveal-delay-1..6 级联淡入

### Requirement: 页面级结构对齐
各页面 SHALL 采用规范第 13 节定义的结构：工作台 Hero+工具栏+网格、创作页左右分栏、详情页返回+Tab+卡片网格、编辑器全屏侧栏工作流、我的页信息卡+设置行。

#### Scenario: 编辑器移动端抽屉
- **WHEN** 视口 <1024px 进入编辑器
- **THEN** 侧栏变为可开合抽屉 + 左下 48px 蓝色浮动开关

## MODIFIED Requirements

### Requirement: Element Plus 组件形态
EP 组件 SHALL 对齐规范第 8/9/17 节：主按钮蓝胶囊顶部高光 + hover 蓝色阴影 + active scale(.97)；输入 44px/12px 圆角/surface 底/focus 3.5px 蓝光环/placeholder 40% 白；弹窗 max-width 480px/24px 圆角/60% 遮罩 + 8px blur；Toast 底部居中白底黑字胶囊。

### Requirement: 顶栏导航
MainLayout SHALL 对齐规范第 12 节（60px 毛玻璃、滚动阴影、36px 胶囊导航 active 10% 白、<768px 汉堡 + 滑入菜单且保留主题入口）。

## REMOVED Requirements

### Requirement: 偏离规范的旧令牌值
**Reason**：文字透明度 .55/.14/.24、圆角 20px、单层柔影、cubic-bezier(.25,.1,.25,1) 缓动与规范不一致。
**Migration**：统一替换为规范值（60%/40% 文字、.08/.12 描边、18/24px 圆角、四级阴影、(.16,1,.3,1) 曲线）；旧变量名保留为别名避免引用断裂。
